#include "Container.h"

// Constructor for Container class
Container::Container()
{
	vehicle = NULL;
	next = NULL;
}
