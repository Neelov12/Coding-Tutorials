#ifndef _CAR_H
#define _CAR_H
// Q1a: Create Car class (5 points)
// Part 1: Create a child class of the Vehicle class named 'Car'
// Part2: Declare constructor which accepts the same 3 parameters as the parent class Vehicle's constructor.
// // Pass the 3 parameters to the super constructor of the Vehicle class.
//
//
// // Part 3: Re-declare the method displayVehicle (virtual method found inside of parent class Vehicle)

#include "vehicle.h"

class Car : public Vehicle {
public: 
	Car(string id, string owner, vehicleType type): Vehicle(id, owner, type) {}
	void displayVehicle();

};
#endif // _CAR_H
