// Q2-b: Define displayVehicle() for Motorcycle class (5 points)
// Define the function displayVehicle() that you declared within the Motorcycle class in the header file
// See expected output in question file.

// (displayList() function in hw10.cpp should call this function.)
// Include necessary header files

#include "motorcycle.h"
#include <iostream>

void Motorcycle::displayVehicle() {
        cout << "Vehicle Registration Id: " << getId() << endl;
        cout << "Owner name: " << getOwner() << endl;
        cout << "This vehicle is a " << getVehicleType() << endl;
}
