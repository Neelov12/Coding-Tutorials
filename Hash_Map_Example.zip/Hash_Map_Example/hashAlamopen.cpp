//
//  hash_Alamopen.cpp
//  CSE310_homework4
//
//  Created by Neelov Alam on 7/1/23.
//

#include <stdio.h>
#include <iostream>
#include <cstdlib>
using namespace std;

class sundevilbank
{
private:
    class key
    {
    public:
        key* next;
        int num;
        string name;
        double balance;
    };


public:
    key* array[753];
    sundevilbank()
    {
        for (int i = 0; i < 753; i++) {
            array[i] = nullptr;
        }
    }
    
    void INSERT_Account(key* [], key* );
    void DELETE_Account(key* [], int);
    void SEARCH_Account(key* [], int);
    
    key* CREATE_KEY(int n, string s, double d) {
        key* z = new key();
        z->next = NULL;
        z->num = n;
        z->name = s;
        z->balance = d;
        
        return z;
    }
};

void sundevilbank::INSERT_Account(key* arg[], key* account) {
    int hk = (account->num) % 753;
    
    key* y = account;
    key* z = arg[hk];
    
    while(z != NULL) {
        z = z->next;
    }
    
    z = y;
}

void sundevilbank::DELETE_Account(key* arg[], int k) {
    key* z = arg[0];
    int index = -1;
    
    
    for (int i = 0; i < 753; i++) {
        if (arg[i]->num == k) {
            index = i;
            break;
        }
    }
    
    if (index != -1) {
        delete arg[index];
        for (int i = index; i < 752; i++) {
            arg[i] = arg[i + 1];
        }
        arg[752] = nullptr;
        cout << "Deleted" << endl;
    }
    else {
        cout << "Key with number " << k << " not found." << endl;
    }
}

void sundevilbank::SEARCH_Account(key* arg[], int k) {
    bool found = false;

        for (int i = 0; i < 753; i++) {
            if (arg[i]->num == k) {
                found = true;
                cout << "Key found at index " << i << ":" << endl;
                cout << "Number: " << arg[i]->num << endl;
                cout << "Name: " << arg[i]->name << endl;
                cout << "Balance: $" << arg[i]->balance << endl;
                break;
            }
        }

        if (found == false) {
            cout << "Not found." << endl;
        }
}


int main() {
    int choice;
    sundevilbank yuh;
    int n;
    string name;
    double balance;
    
    cout << "Welcome to Sun Devil Bank" << endl;
    while (true)
    {
        cout << endl << endl;
        cout << " Options " << endl;
        cout << " --------" << endl;
        cout << " 1. Insert Account " << endl;
        cout << " 2. Delete Account " << endl;
        cout << " 3. Search Account " << endl;
        cout << " 4. Exit " << endl;
        cout << " Enter your choice : ";
        cin >> choice;
        
        switch (choice)
        {
            case 1:
                cout << " Enter account number (int value) to be inserted : ";
                cin >> n;
                if (n < 100001 || n > 999999) {
                    cout << "Number must be between 100001 and 999999" << endl;
                    break;
                }
                cout << " Enter account name (string value) to be inserted : ";
                cin >> name;
                cout << " Enter account balance (double value) to be inserted : ";
                cin >> balance;
                
                yuh.INSERT_Account(yuh.array, yuh.CREATE_KEY(n, name, balance));
                break;
            case 2:
                cout << " Enter account number (int value) to be deleted : ";
                cin >> n;
                
                yuh.DELETE_Account(yuh.array, n);
            case 3:
                cout << " Enter account number (int value) you would like to find : ";
                cin >> n;
                
                yuh.SEARCH_Account(yuh.array, n);
            case 4:
                system("pause");
                return 0;
                break;
            default:
                cout << "Invalid choice";
        }
        
    }
}
